from django.apps import AppConfig


class MyadminConfig(AppConfig):
    name = 'myadmin'
