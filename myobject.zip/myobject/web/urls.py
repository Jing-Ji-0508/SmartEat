#The child route of the web management system
from django.urls import path,include
from web.views import index,cart

urlpatterns = [
    path('', index.index,name="index"),

    #The routes of The front-end  logs in /out
    path('login', index.login,name="web_login"),#loading the login form
    path('dologin', index.dologin,name="web_dologin"),#perform the login 
    path('logout', index.logout,name="web_logout"),#perform the logout
    path('verify', index.verify,name="web_verify"),#output the verification code

    path('web/',include([
        path('', index.webindex, name="web_index"), #ChecKOUT Couter ordering home page
        #Cart information management url
        path('cart/add/<str:pid>', cart.add , name="web_cart_add"), 
        path('cart/delete/<str:pid>', cart.delete , name="web_cart_delete"), 
        path('cart/clear', cart.clear , name="web_cart_clear"), 
        path('cart/change', cart.change , name="web_cart_change"), 
    ]))


]
