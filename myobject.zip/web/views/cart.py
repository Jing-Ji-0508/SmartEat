#ordering list management
from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect
from django.urls import reverse
from myadmin.models import User

# Create your views here.


def add(request,pid):
    ''' Add meal on the odering list '''
    pass

def delete(request,pid):
    ''' Delete meal on the odering list '''
    pass
def clear(request):
    ''' empty the shopping list '''
    pass
def change(request):
    ''' change the information of meal on the odering list '''
    pass