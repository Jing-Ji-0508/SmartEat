#order information management
from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect
from django.urls import reverse
from datetime import datetime
from django.core.paginator import Paginator

from myadmin.models import Orders,OrderDetail,Payment

# Create your views here.

def index(request,pIndex=1):
    
    umod = Orders.objects
    sid = 1 #Get the current store ID
    ulist = umod.filter(shop_id=sid)
    mywhere=[]
    status = request.GET.get('status','')
    if status != '':
        ulist = ulist.filter(status=status)
        mywhere.append("status="+status)
        
    ulist = ulist.order_by("id")
    pIndex = int(pIndex)
    page = Paginator(ulist,10) 
    maxpages = page.num_pages 
    if pIndex > maxpages:
        pIndex = maxpages
    if pIndex < 1:
        pIndex = 1
    list2 = page.page(pIndex) 
    plist = page.page_range 

  

    context = {"orderslist":list2,'plist':plist,'pIndex':pIndex,'maxpages':maxpages,'mywhere':mywhere}
    return render(request,"web/list.html",context)


def insert(request):
    ''' Execute order adding '''
    try:
        
        od = Orders()
       
        od.shop_id = 1
        od.member_id = 0
        od.user_id =0
        od.money = request.session['total_money']
        od.status = 1 #Order status :1 in processing /2 invalid /3 completed
        od.payment_status = 2 #Payment status :1 unpaid /2 paid /3 refunded
        od.create_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        od.update_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        od.save()

        #Perform payment information addition
        op = Payment()
        op.order_id = od.id 
        op.member_id = 0
        op.type = 2
        op.bank = request.GET.get("bank",3) 
        op.money = request.session['total_money']
        op.status = 2 
        op.create_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        op.update_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        op.save()

        #Perform the addition of order details
        cartlist = request.session.get("cartlist",{}) 
       
        for item in cartlist.values():
            ov = OrderDetail()
            ov.order_id = od.id  
            ov.product_id = item['id']  
            ov.product_name = item['name'] 
            ov.price = item['price']     
            ov.quantity = item['num']  
            ov.status = 1 
            ov.save()

        del request.session["cartlist"]
        del request.session['total_money']
        return HttpResponse("Y")
    except Exception as err:
        print(err)
        return HttpResponse("N")

def detail(request):
    ''' Loading Order Details '''
    oid = request.GET.get("oid",0)
    dlist = OrderDetail.objects.filter(order_id=oid)
    context = {"detaillist":dlist}
    return render(request,"web/detail.html",context)

def status(request):
    ''' Modify order status '''
    try:
        oid = request.GET.get("oid",0)
        ob = Orders.objects.get(id=oid)
        ob.status = request.GET['status']
        ob.save()
        return HttpResponse("Y")
    except Exception as err:
        print(err)
        return HttpResponse("N")